class Credentials:
    AWS_ACCESS_KEY_ID = ''
    SECRET_ACCESS_KEY = ''
    vcq_name = ''
    OWNER_ID = ''
class Credentials:
    AWS_ACCESS_KEY_ID = 'AKIA3QP7SNLSE4QDEBXG'
    SECRET_ACCESS_KEY = '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'
    vcq_name = 'VoiceControlQueue.fifo'
    OWNER_ID = '791346834148'